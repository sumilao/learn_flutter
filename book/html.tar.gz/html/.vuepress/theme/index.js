module.exports = {
  extend: '@vuepress/theme-default',
  globalLayout: './layouts/GlobalLayout.vue'
}
